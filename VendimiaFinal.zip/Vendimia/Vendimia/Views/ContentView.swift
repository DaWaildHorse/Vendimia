import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationBarView()
    }
}

#Preview {
    ContentView()
}
